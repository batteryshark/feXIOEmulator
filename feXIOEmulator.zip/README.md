# feXIOEmulator

## Background
This library adds keyboard input to the arcade game "Frenzy Express" - a Korean Crazy Taxi clone with a scooter!

## What Works

Everything from what I can tell.

Controls:

F2 - Service Button

F3 - Test Mode (Operator Menu)

1 - Insert Coins

Left Arrow - Steer Left / Left Selection Button

Right Arrow - Steer Right / Right Selection Button

Enter/Return - Start Button

Z - Left Pedal

X - Right Pedal

LShift - Hard Brake (might need to be harder, lemme know)

LCtrl - Half-Brake (guessing like a handbrake? idk)

## What doesn't yet
Nothing from what I can tell - try it out and lemme know.
